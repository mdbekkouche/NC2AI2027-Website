# NC2AI 2027 Author Kit

